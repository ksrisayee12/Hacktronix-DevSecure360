# backend/app/scanner/sast/rules/loader.py
"""
YAML rule file loader for the DevSecure360 SAST engine.

Loads all YAML rule files for a given language from:
    scanner/sast/rules/{language}/*.yaml

Returns a combined dict: {rule_id: rule_dict}
"""

import yaml
import os


def load_rules(language: str = "python") -> dict:
    """
    Load all YAML rule files for a given language.
    Returns a dict: {rule_id: rule_dict}

    Rule files live at: scanner/sast/rules/{language}/*.yaml
    """
    rules_dir = os.path.join(os.path.dirname(__file__), language)
    rules = {}

    if not os.path.exists(rules_dir):
        print(f"[rules/loader] No rules directory found for language: {language}")
        return rules

    loaded_count = 0
    collision_count = 0
    error_count = 0

    for filename in sorted(os.listdir(rules_dir)):
        if not filename.endswith(".yaml") and not filename.endswith(".yml"):
            continue
        filepath = os.path.join(rules_dir, filename)
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                rule = yaml.safe_load(f)
            if not rule or "rule_id" not in rule:
                print(f"[rules/loader] WARNING: {filename} missing 'rule_id', skipping")
                continue
            
            rule_id = rule["rule_id"]
            if rule_id in rules:
                # Collision: merge sinks and sources from both rules into the first one
                existing = rules[rule_id]
                existing_sinks = existing.get("sinks", [])
                new_sinks = rule.get("sinks", [])
                merged_sinks = list(dict.fromkeys(existing_sinks + new_sinks))  # dedup, preserve order
                existing["sinks"] = merged_sinks
                
                existing_sources = existing.get("sources", [])
                new_sources = rule.get("sources", [])
                existing["sources"] = list(dict.fromkeys(existing_sources + new_sources))
                
                # Keep the better remediation (longer = more detailed)
                if len(rule.get("remediation", "")) > len(existing.get("remediation", "")):
                    existing["remediation"] = rule["remediation"]
                collision_count += 1
            else:
                rules[rule_id] = rule
                loaded_count += 1
        except Exception as e:
            print(f"[rules/loader] WARNING: failed to load {filepath}: {e}")
            error_count += 1

    print(f"[rules/loader] {language}: {loaded_count} rules loaded, {collision_count} merged (duplicate IDs), {error_count} errors")

    return rules


def load_all_rules() -> dict[str, dict]:
    """
    Load rules for ALL supported languages.
    Returns: {
        "python": { rule_id: rule },
        "javascript": { rule_id: rule },
        ...
    }
    """
    languages = ["python", "javascript", "java", "php", "c", "cpp", "go", "csharp"]
    all_rules = {}
    for lang in languages:
        all_rules[lang] = load_rules(lang)
    return all_rules
